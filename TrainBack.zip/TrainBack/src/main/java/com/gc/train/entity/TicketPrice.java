package com.gc.train.entity;

import com.gc.train.entity.basic.EntityMine;

public class TicketPrice implements EntityMine {

  public Integer id;

  public String station_train_code	;
  public String from_station_code	;
  public String to_station_code	;
  public Float swz	;

  public Float getTdz() {
    return tdz;
  }

  public void setTdz(Float tdz) {
    this.tdz = tdz;
  }

  public Float tdz	;
  public Float ydz	;
  public Float edz	;
  public Float gjrw	;
  public Float rw	;
  public Float dw	;
  public Float yw	;
  public Float rz	;
  public Float yz	;
  public Float wz	;
  public Float other	;

  @Override
  public Integer getId() {
    return id;
  }

  @Override
  public void setId(Integer id) {
    this.id = id;
  }

  public String getStation_train_code() {
    return station_train_code;
  }

  public void setStation_train_code(String station_train_code) {
    this.station_train_code = station_train_code;
  }

  public String getFrom_station_code() {
    return from_station_code;
  }

  public void setFrom_station_code(String from_station_code) {
    this.from_station_code = from_station_code;
  }

  public String getTo_station_code() {
    return to_station_code;
  }

  public void setTo_station_code(String to_station_code) {
    this.to_station_code = to_station_code;
  }

  public Float getSwz() {
    return swz;
  }

  public void setSwz(Float swz) {
    this.swz = swz;
  }

  public Float getYdz() {
    return ydz;
  }

  public void setYdz(Float ydz) {
    this.ydz = ydz;
  }

  public Float getEdz() {
    return edz;
  }

  public void setEdz(Float edz) {
    this.edz = edz;
  }

  public Float getGjrw() {
    return gjrw;
  }

  public void setGjrw(Float gjrw) {
    this.gjrw = gjrw;
  }

  public Float getRw() {
    return rw;
  }

  public void setRw(Float rw) {
    this.rw = rw;
  }

  public Float getDw() {
    return dw;
  }

  public void setDw(Float dw) {
    this.dw = dw;
  }

  public Float getYw() {
    return yw;
  }

  public void setYw(Float yw) {
    this.yw = yw;
  }

  public Float getRz() {
    return rz;
  }

  public void setRz(Float rz) {
    this.rz = rz;
  }

  public Float getYz() {
    return yz;
  }

  public void setYz(Float yz) {
    this.yz = yz;
  }

  public Float getWz() {
    return wz;
  }

  public void setWz(Float wz) {
    this.wz = wz;
  }

  public Float getOther() {
    return other;
  }

  public void setOther(Float other) {
    this.other = other;
  }

  @Override
  public String toString() {
    return "TicketPrice{" +
        "id=" + id +
        ", station_train_code='" + station_train_code + '\'' +
        ", from_station_code='" + from_station_code + '\'' +
        ", to_station_code='" + to_station_code + '\'' +
        ", swz=" + swz +
        ", tdz=" + tdz +
        ", ydz=" + ydz +
        ", edz=" + edz +
        ", gjrw=" + gjrw +
        ", rw=" + rw +
        ", dw=" + dw +
        ", yw=" + yw +
        ", rz=" + rz +
        ", yz=" + yz +
        ", wz=" + wz +
        ", other=" + other +
        '}';
  }
}