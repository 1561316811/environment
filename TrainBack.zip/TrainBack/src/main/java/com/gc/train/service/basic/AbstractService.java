package com.gc.train.service.basic;

import com.gc.train.dao.basic.BasicMapper;
import com.gc.train.entity.basic.EntityMine;
import com.gc.train.util.PageUtil;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public abstract class AbstractService<T extends EntityMine>
implements BasicService<T> {
	
	protected BasicMapper<T> basicMapper;
	
	public AbstractService(BasicMapper<T> basicMapper) {
		super();
		this.basicMapper = basicMapper;
	}

	@Override
	final public void add(T entity) {
		basicMapper.add(entity);
	}

	@Override
	final public void update(T entity) {
		basicMapper.update(entity);
	}
	
	@Override
	final public void delete(List<Integer> ids) {
		basicMapper.delete(ids);
	}
	
	final protected Map generateTempMap(){
		return new HashMap();
	}
	
	
	@Override
	final public T query(Integer id) {
		return basicMapper.findById(id);
	}

	@Override
	final public List<T> queryAll() {
		return basicMapper.findAll();
	}

	@Override
	final public PageUtil<T> queryPage(Integer page) {
		return basicMapper.findByPage(page);
	}


}
