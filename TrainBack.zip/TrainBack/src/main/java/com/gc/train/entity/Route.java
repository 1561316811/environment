package com.gc.train.entity;

import com.gc.train.entity.basic.EntityMine;

public class Route implements EntityMine {

  private Integer id;

  private String station_train_code	;
  private String station_code	;
  private String station_name	;
  private String start_time	;
  private String arrive_time	;
  private String station_no	;

  @Override
  public Integer getId() {
    return id;
  }

  @Override
  public void setId(Integer id) {
    this.id = id;
  }

  public String getStation_train_code() {
    return station_train_code;
  }

  public void setStation_train_code(String station_train_code) {
    this.station_train_code = station_train_code;
  }

  public String getStation_code() {
    return station_code;
  }

  public void setStation_code(String station_code) {
    this.station_code = station_code;
  }

  public String getStation_name() {
    return station_name;
  }

  public void setStation_name(String station_name) {
    this.station_name = station_name;
  }

  public String getStart_time() {
    return start_time;
  }

  public void setStart_time(String start_time) {
    this.start_time = start_time;
  }

  public String getArrive_time() {
    return arrive_time;
  }

  public void setArrive_time(String arrive_time) {
    this.arrive_time = arrive_time;
  }

  public String getStation_no() {
    return station_no;
  }

  public void setStation_no(String station_no) {
    this.station_no = station_no;
  }

  @Override
  public String toString() {
    return "Route{" +
        "id=" + id +
        ", station_train_code='" + station_train_code + '\'' +
        ", station_code='" + station_code + '\'' +
        ", station_name='" + station_name + '\'' +
        ", start_time='" + start_time + '\'' +
        ", arrive_time='" + arrive_time + '\'' +
        ", station_no='" + station_no + '\'' +
        '}';
  }
}