package com.gc.train.entity;

import com.gc.train.entity.basic.EntityUser;

public class User implements EntityUser {

	private Integer id;
	private String userName;
	private String password;

/*	private String avatarPath;
	private Integer userType;
	private String birthday;
	private String address;
	private String phoneNum;
	private String realName;
	private Integer sex;*/
	
	
	@Override
	public Integer getId() {
		return id;
	}

	@Override
	public void setId(Integer id) {
		this.id = id;
	}

	@Override
	public String getUserName() {
		return userName;
	}
	

	public void setUserName(String userName) {
		this.userName = userName;
	}

	@Override
	public String getPassword() {
		return password;
	}

	@Override
	public void setPassword(String password) {
		this.password = password;
	}


}
