package com.gc.train.entity;

public class Passenger extends User {


	private String username	;
	private String password	;
	private String cardType	;
	private String email	;
	private int sex	;
	private String card_no	;
	private String phone_num	;
	private String nation	;
	private String education_background	;
	private String company	;
	private String income_year	;
	private String solid_phone	;
	private String live_city	;
	private String address_detail	;
	private String marriage_status	;
	private String job	;
	private String duty	;
	private String postcode	;
	private String fax	;
	private String check_status	;
	private String passenger_type	;


	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@Override
	public String getPassword() {
		return password;
	}

	@Override
	public void setPassword(String password) {
		this.password = password;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getSex() {
		return sex;
	}

	public void setSex(int sex) {
		this.sex = sex;
	}

	public String getCard_no() {
		return card_no;
	}

	public void setCard_no(String card_no) {
		this.card_no = card_no;
	}

	public String getPhone_num() {
		return phone_num;
	}

	public void setPhone_num(String phone_num) {
		this.phone_num = phone_num;
	}

	public String getNation() {
		return nation;
	}

	public void setNation(String nation) {
		this.nation = nation;
	}

	public String getEducation_background() {
		return education_background;
	}

	public void setEducation_background(String education_background) {
		this.education_background = education_background;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getIncome_year() {
		return income_year;
	}

	public void setIncome_year(String income_year) {
		this.income_year = income_year;
	}

	public String getSolid_phone() {
		return solid_phone;
	}

	public void setSolid_phone(String solid_phone) {
		this.solid_phone = solid_phone;
	}

	public String getLive_city() {
		return live_city;
	}

	public void setLive_city(String live_city) {
		this.live_city = live_city;
	}

	public String getAddress_detail() {
		return address_detail;
	}

	public void setAddress_detail(String address_detail) {
		this.address_detail = address_detail;
	}

	public String getMarriage_status() {
		return marriage_status;
	}

	public void setMarriage_status(String marriage_status) {
		this.marriage_status = marriage_status;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public String getDuty() {
		return duty;
	}

	public void setDuty(String duty) {
		this.duty = duty;
	}

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getCheck_status() {
		return check_status;
	}

	public void setCheck_status(String check_status) {
		this.check_status = check_status;
	}

	public String getPassenger_type() {
		return passenger_type;
	}

	public void setPassenger_type(String passenger_type) {
		this.passenger_type = passenger_type;
	}

	@Override
	public String toString() {
		return "passenger{" +
				"username='" + username + '\'' +
				", password='" + password + '\'' +
				", cardType='" + cardType + '\'' +
				", email='" + email + '\'' +
				", sex=" + sex +
				", card_no='" + card_no + '\'' +
				", phone_num='" + phone_num + '\'' +
				", nation='" + nation + '\'' +
				", education_background='" + education_background + '\'' +
				", company='" + company + '\'' +
				", income_year='" + income_year + '\'' +
				", solid_phone='" + solid_phone + '\'' +
				", live_city='" + live_city + '\'' +
				", address_detail='" + address_detail + '\'' +
				", marriage_status='" + marriage_status + '\'' +
				", job='" + job + '\'' +
				", duty='" + duty + '\'' +
				", postcode='" + postcode + '\'' +
				", fax='" + fax + '\'' +
				", check_status='" + check_status + '\'' +
				", passenger_type='" + passenger_type + '\'' +
				'}';
	}
}
