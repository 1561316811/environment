package com.gc.train.service.basic;

import com.gc.train.entity.basic.EntityMine;
import com.gc.train.util.PageUtil;

import java.util.List;

public interface BasicService<T extends EntityMine> {

	void add(T dto);

	T query(Integer id);

	List<T> queryAll();

	PageUtil<T> queryPage(Integer page);

	void update(T dto);

	void delete(List<Integer> ids);

}
