package com.gc.train.entity.basic;

public interface EntityMine {
	
	Integer getId();
	
	void setId(Integer id);

}
