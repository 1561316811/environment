package com.gc.train.dao.impl;

import com.gc.train.dao.TrainMapper;
import com.gc.train.entity.Train;
import com.gc.train.util.PageUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;

@Repository("trainMapperImpl")
public class TrainMapperImpl implements TrainMapper {

	@Autowired
	TrainMapper trainMapper;

	@Override
	public Train findById(Integer id) {
		return null;
	}

	@Override
	public List<Train> findByMap(Train entity) {
		return trainMapper.findByMap(entity);
	}

	@Override
	public long findAllCount() {
		return 0;
	}

	@Override
	public List<Train> findAll() {
		return null;
	}

	@Override
	public void delete(List<Integer> ids) {

	}

	@Override
	public void update(Train entity) {

	}

	@Override
	public void add(Train train) {
		trainMapper.add(train);
	}

	@Override
	public void addAll(Collection<Train> entities) {

	}

	@Override
	public PageUtil<Train> findByPage(int page) {
		return null;
	}


}
