package com.gc.train.dao.basic;

import com.gc.train.entity.basic.EntityMine;
import com.gc.train.util.PageUtil;

import java.util.Collection;
import java.util.List;

public interface BasicMapper<T extends EntityMine> {
	
	/**
	 * find entity by id.
	 * @param id
	 * @return
	 */
	T findById(Integer id);
	
	List<T> findByMap(T entity);
	/**
	 * Finding all count from sql
	 * @return
	 */
	long findAllCount();
	
	/**
	 * Finding all result from sql
	 * @return
	 */
	List<T> findAll();
	
	/**
	 * to delete entities, one or more
	 * @param ids
	 */
	void delete(List<Integer> ids);
	
	/**
	 * delete all.
	 */
//	void deleteAll();
	
	/**
	 * update entity data
	 * @param entity
	 */
	void update(T entity);
	
	/**
	 * add entity data
	 * @param entity
	 */
	void add(T entity);
	
	/**
	 * add same entities data
	 * @param entities
	 */
//	@SuppressWarnings("unchecked")
	void addAll(Collection<T> entities);
	
	/**
	 * find entities by page
	 * @param page
	 * @return
	 */
	PageUtil<T> findByPage(int page);

}
