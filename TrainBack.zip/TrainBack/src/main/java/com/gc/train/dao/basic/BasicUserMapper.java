package com.gc.train.dao.basic;

import com.gc.train.entity.basic.EntityUser;

public interface BasicUserMapper<T extends EntityUser>
	extends BasicMapper<T> {
	
	/**
	 * find entity by user name;
	 * @param userName userName.
	 * @return
	 */
	T findByUserName(String userName);
	
	String findPasswordByUserName(String userName);
	
	
}
