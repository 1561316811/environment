package com.gc.train.controller;



import com.gc.train.entity.User;
import com.gc.train.service.UserLoginService;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/user")
public class UserLoginController {

  Logger log = LogManager.getLogger(UserLoginController.class);

  @Autowired
  private UserLoginService service;

  @PostMapping("/login")
  public boolean login(User user, Model model, HttpServletRequest request){

    log.info("userName " + user.getUserName());
    log.info("password " + user.getPassword());
    if (service.logIn(user)) {
      User u = service.findByUserName(user.getUserName());
      model.addAttribute("userType", u);
      request.getSession().setAttribute("userType", u);
      return true;
    }
    return false;
  }

  @RequestMapping(value = "/logout", method = { RequestMethod.GET})
  public boolean logout(HttpServletRequest request) {
    request.getSession().invalidate();
    return true;
  }


}
