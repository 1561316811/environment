package com.gc.train.dao;

import com.gc.train.dao.basic.BasicMapper;
import com.gc.train.entity.TicketPrice;

import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface TicketPriceMapper extends BasicMapper<TicketPrice> {

}