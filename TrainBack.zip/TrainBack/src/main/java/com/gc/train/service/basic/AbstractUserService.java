package com.gc.train.service.basic;


import com.gc.train.dao.basic.BasicMapper;
import com.gc.train.dao.basic.BasicUserMapper;
import com.gc.train.entity.basic.EntityUser;

public abstract class AbstractUserService<T extends EntityUser>
	extends AbstractService<T> implements BasicUserService<T> {
	
	protected BasicUserMapper<T> userMapper;
	
	public AbstractUserService(BasicUserMapper<T> userMapper) {
		super((BasicMapper<T>) userMapper);
		this.userMapper = userMapper;
	}
	
	@Override
	final public boolean isExist(String userName){
		
		if(userMapper.findByUserName(userName) == null)
			return false;
		return true;
		
	}
	
	@Override
	final public boolean modifyPassword(String userName, String oldPassword, String newPassword){
		T entity = userMapper.findByUserName(userName);
		if(entity.getPassword().equals(oldPassword)){
			entity.setPassword(newPassword);
			userMapper.update(entity);
			return true;
		}
		return false;
	}

	
	@Override
	final public boolean logIn(T user){
		
		T u = userMapper.findByUserName(user.getUserName());
//		System.out.println("user :" + u);
		if(u != null && u.getPassword().equals(user.getPassword())){
			return true;
		}
		return false;
	}
	
	@Override
	final public T findByUserName(String userName){
		return userMapper.findByUserName(userName);
	}

}
