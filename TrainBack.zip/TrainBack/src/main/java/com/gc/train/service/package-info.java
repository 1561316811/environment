/**
 * 
 */
/**
 * Service ��ӿ�
 * @author 0001
 *
 */
package com.gc.train.service;