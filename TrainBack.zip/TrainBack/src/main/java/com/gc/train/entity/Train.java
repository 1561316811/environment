package com.gc.train.entity;

import com.gc.train.entity.basic.EntityMine;

public class Train implements EntityMine {

  private Integer id;

  private String station_train_code	;

  private String train_no	;

  private String from_station_code	;
  private String to_station_code	;

  public String getFrom_station_code() {
    return from_station_code;
  }

  public void setFrom_station_code(String from_station_code) {
    this.from_station_code = from_station_code;
  }

  public String getTo_station_code() {
    return to_station_code;
  }

  public void setTo_station_code(String to_station_code) {
    this.to_station_code = to_station_code;
  }

  @Override
  public Integer getId() {
    return id;
  }

  @Override
  public void setId(Integer id) {
    this.id = id;
  }

  public String getStation_train_code() {
    return station_train_code;
  }

  public void setStation_train_code(String station_train_code) {
    this.station_train_code = station_train_code;
  }

  public String getTrain_no() {
    return train_no;
  }

  public void setTrain_no(String train_no) {
    this.train_no = train_no;
  }
}