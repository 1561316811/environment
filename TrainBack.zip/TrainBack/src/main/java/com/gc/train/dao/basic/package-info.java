/**
 * 
 */
/**
 * @author 0001
 *
 */
package com.gc.train.dao.basic;