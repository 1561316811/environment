package com.gc.train.dao.impl;

import com.gc.train.dao.AdminMapper;
import com.gc.train.dao.UserMapper;
import com.gc.train.entity.Admin;
import com.gc.train.util.PageUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;

@Repository
public class AdminMapperImpl implements AdminMapper {
	
	@Autowired
  AdminMapper adminMapper;
	@Autowired
  UserMapper userMapper;

	@Override
	public Admin findByUserName(String userName) {
		return adminMapper.findByUserName(userName);
	}

	@Override
	public String findPasswordByUserName(String userName) {
		// TODO Auto-generated method stub
		return adminMapper.findPasswordByUserName(userName);
	}

	@Override
	public Admin findById(Integer id) {
		// TODO Auto-generated method stub
		return adminMapper.findById(id);
	}

	@Override
	public long findAllCount() {
		// TODO Auto-generated method stub
		return adminMapper.findAllCount();
	}

	@Override
	public List<Admin> findAll() {
		// TODO Auto-generated method stub
		return adminMapper.findAll();
	}

	@Override
	public void delete(List<Integer> ids) {
		adminMapper.delete(ids);
	}

	@Override
	public void update(Admin entity) {
		userMapper.update(entity);
		adminMapper.update(entity);
	}

	@Override
	public void add(Admin entity) {
		userMapper.add(entity);
		adminMapper.add(entity);
	}

	@Override
	public void addAll(Collection<Admin> entities) {
		Collection c = entities;
		
		userMapper.addAll(c);
		adminMapper.addAll(entities);
	}

	@Override
	public PageUtil<Admin> findByPage(int page) {
		return null;
	}

	/*
	 *通过map查询管理员 
	 */
	@Override
	public List<Admin> findByMap(Admin entity) {
		return adminMapper.findByMap(entity);
	}
	

	

}
