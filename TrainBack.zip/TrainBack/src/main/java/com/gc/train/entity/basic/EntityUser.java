package com.gc.train.entity.basic;

public interface EntityUser extends EntityMine {
	
	String getUserName();
	
	String getPassword();
	
	void setPassword(String password);

}
