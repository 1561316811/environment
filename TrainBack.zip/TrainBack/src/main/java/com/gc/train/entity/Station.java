package com.gc.train.entity;

import com.gc.train.entity.basic.EntityMine;

public class Station implements EntityMine {

  private Integer id;

  private String station_code;

  private String station_name;

  private String station_pinying;

  private String station_pinying_simple;

  private int station_no;

  @Override
  public Integer getId() {
    return id;
  }

  @Override
  public void setId(Integer id) {
    this.id = id;
  }

  public String getStation_code() {
    return station_code;
  }

  public void setStation_code(String station_code) {
    this.station_code = station_code;
  }

  public String getStation_name() {
    return station_name;
  }

  public void setStation_name(String station_name) {
    this.station_name = station_name;
  }

  public String getStation_pinying() {
    return station_pinying;
  }

  public void setStation_pinying(String station_pinying) {
    this.station_pinying = station_pinying;
  }

  public String getStation_pinying_simple() {
    return station_pinying_simple;
  }

  public void setStation_pinying_simple(String station_pinying_simple) {
    this.station_pinying_simple = station_pinying_simple;
  }

  public int getStation_no() {
    return station_no;
  }

  public void setStation_no(int station_no) {
    this.station_no = station_no;
  }
}