package com.gc.train.dao.impl;

import com.gc.train.dao.RouteMapper;
import com.gc.train.entity.Route;
import com.gc.train.util.PageUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;

@Repository("routeMapperImpl")
public class RouteMapperImpl implements RouteMapper {

	@Autowired
	RouteMapper routeMapper;

	@Override
	public Route findById(Integer id) {
		return null;
	}

	@Override
	public List<Route> findByMap(Route entity) {
		return null;
	}

	@Override
	public long findAllCount() {
		return 0;
	}

	@Override
	public List<Route> findAll() {
		return null;
	}

	@Override
	public void delete(List<Integer> ids) {

	}

	@Override
	public void update(Route entity) {

	}

	@Override
	public void add(Route route) {
		routeMapper.add(route);
	}

	@Override
	public void addAll(Collection<Route> entities) {

	}

	@Override
	public PageUtil<Route> findByPage(int page) {
		return null;
	}


}
