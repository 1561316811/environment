package com.gc.train.entity;

public class Admin extends User {


	
}
