package com.gc.train.dao.impl;

import com.gc.train.dao.StationMapper;
import com.gc.train.entity.Station;
import com.gc.train.util.PageUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;

@Repository("stationMapperImpl")
public class StationMapperImpl implements StationMapper {


	@Autowired
  StationMapper stationMapper;

	@Override
	public Station findById(Integer id) {
		return null;
	}

	@Override
	public List<Station> findByMap(Station entity) {
		return stationMapper.findByMap(entity);
	}

	@Override
	public long findAllCount() {
		return 0;
	}

	@Override
	public List<Station> findAll() {
		return null;
	}

	@Override
	public void delete(List<Integer> ids) {

	}

	@Override
	public void update(Station entity) {

	}

	@Override
	public void add(Station station) {
		stationMapper.add(station);
	}

	@Override
	public void addAll(Collection<Station> entities) {

	}

	@Override
	public PageUtil<Station> findByPage(int page) {
		return null;
	}


}
