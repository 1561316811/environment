package com.gc.train;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainBackApplication.class, args);
	}

}
