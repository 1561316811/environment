package com.gc.train.dao.impl;

import com.gc.train.dao.TicketPriceMapper;
import com.gc.train.entity.TicketPrice;
import com.gc.train.util.PageUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;

@Repository("ticketPriceMapperImpl")
public class TicketPriceMapperImpl implements TicketPriceMapper {

	@Autowired
  TicketPriceMapper ticketPriceMapper;

	@Override
	public TicketPrice findById(Integer id) {
		return null;
	}

	@Override
	public List<TicketPrice> findByMap(TicketPrice entity) {
		return ticketPriceMapper.findByMap(entity);
	}

	@Override
	public long findAllCount() {
		return 0;
	}

	@Override
	public List<TicketPrice> findAll() {
		return null;
	}

	@Override
	public void delete(List<Integer> ids) {

	}

	@Override
	public void update(TicketPrice entity) {

	}

	@Override
	public void add(TicketPrice ticketPrice) {
		ticketPriceMapper.add(ticketPrice);
	}

	@Override
	public void addAll(Collection<TicketPrice> entities) {

	}

	@Override
	public PageUtil<TicketPrice> findByPage(int page) {
		return null;
	}


}
