package com.gc.train.dao;

import com.gc.train.dao.basic.BasicUserMapper;
import com.gc.train.entity.Admin;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface AdminMapper extends BasicUserMapper<Admin>{


}
