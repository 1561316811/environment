package com.gc.train.service;

import com.gc.train.dao.basic.BasicUserMapper;
import com.gc.train.entity.User;
import com.gc.train.service.basic.AbstractUserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class UserLoginService extends AbstractUserService<User> {

  @Autowired
  public UserLoginService(BasicUserMapper<User> userMapper) {
    super(userMapper);
  }



}
